<?php require_once('device.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <title>WURFL Device Inspection</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<h1>WURFL Tester!</h1>
<div id="testform">

</div>
<div id="devicedata">
  <h2>Device Data</h2>

</div>
</body>
</html>